import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Auth           from './components/Auth/Auth';
import RPwd           from "./components/Auth/password reset/resetPassword";
import CoordDashboard from "./components/Coord/CoordDashboard";
import PrivateRoute   from "./components/Coord/PrivateRoute";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/"                element={<Auth />} />
          <Route path="/reset-password"  element={<RPwd />} />
          <Route path="/coord/dashboard" element={
            <PrivateRoute>
              <CoordDashboard />
            </PrivateRoute>
          } />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;