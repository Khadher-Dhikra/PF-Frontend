export default function PrivateRoute({ children }) {
  const token = localStorage.getItem("coord_token");

  if (!token) {
    window.location.href = "/coord/login";
    return null;
  }

  return children;
}