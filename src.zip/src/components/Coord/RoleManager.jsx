import { useState, useEffect } from "react";

export default function RoleManager() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const token = localStorage.getItem("coord_token");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch(
        "http://localhost:8000/api/get-users.php",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": token
          }
        }
      );
      const data = await response.json();
      if (data.status === "success") {
        setUsers(data.users);
      } else {
        setMessage(data.message);
      }
    } catch (error) {
      setMessage("Server error");
    }
    setLoading(false);
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      const response = await fetch(
        "http://localhost:8000/api/update-role.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": token
          },
          body: JSON.stringify({ user_id: userId, role: newRole })
        }
      );
      const data = await response.json();

      if (data.status === "success") {
        setUsers(users.map(u =>
          u.id === userId ? { ...u, role: newRole } : u
        ));
        setMessage("Rôle mis à jour ✅");
        setTimeout(() => setMessage(""), 2000);
      } else {
        setMessage(data.message);
      }
    } catch (error) {
      setMessage("Server error");
    }
  };

  if (loading) return <p>Chargement...</p>;

  return (
    <div>
      <h2>Gestion des rôles</h2>

      {message && (
        <p style={{ color: message.includes("✅") ? "green" : "red", marginBottom: "1em" }}>
          {message}
        </p>
      )}

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "indigo", color: "white" }}>
            <th style={{ padding: "0.7em", textAlign: "left" }}>Nom</th>
            <th style={{ padding: "0.7em", textAlign: "left" }}>Email</th>
            <th style={{ padding: "0.7em", textAlign: "left" }}>Rôle actuel</th>
            <th style={{ padding: "0.7em", textAlign: "left" }}>Changer rôle</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, i) => (
            <tr
              key={u.id}
              style={{ background: i % 2 === 0 ? "#f9f9f9" : "white", borderBottom: "1px solid #eee" }}
            >
              <td style={{ padding: "0.7em" }}>{u.username}</td>
              <td style={{ padding: "0.7em" }}>{u.email}</td>
              <td style={{ padding: "0.7em" }}>
                <span style={{
                  background: u.role === "coordonnateur" ? "#cce5ff" : "#d4edda",
                  color:      u.role === "coordonnateur" ? "#004085" : "#155724",
                  padding: "0.2em 0.7em",
                  borderRadius: "12px",
                  fontSize: "0.85em"
                }}>
                  {u.role}
                </span>
              </td>
              <td style={{ padding: "0.7em" }}>
                <select
                  value={u.role}
                  onChange={(e) => handleRoleChange(u.id, e.target.value)}
                  style={{ padding: "0.3em", borderRadius: "4px", border: "1px solid #b9b8b8" }}
                >
                  <option value="etudiant">etudiant</option>
                  <option value="coordonnateur">coordonnateur</option>
                  <option value="encadrant">encadrant</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}