import { useState } from "react";

export default function CoordLogin({ goToLogin, onSuccess }) {  // ← 1. Ajouter les props
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:8000/api/coord-login.php",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData)
        }
      );

      const data = await response.json();

      if (data.status === "success") {
        localStorage.setItem("coord_token", data.token);
        localStorage.setItem("coord_id",    data.coordinateur.id);
        localStorage.setItem("coord_nom",   data.coordinateur.nom);

        onSuccess();  // ← 2. Remplacer window.location.href par onSuccess()

      } else {
        setMessage(data.message);
      }

    } catch (error) {
      setMessage("Server error");
      console.error(error);
    }

    setLoading(false);
  };

  return (
    <div className="Ldiv">
      <form onSubmit={handleSubmit}>
        <h1>Espace Coordonnateur</h1>
        <p className="pd">Connectez-vous avec votre email professionnel</p>

        <label htmlFor="coord-email">Email professionnel</label>
        <input
          id="coord-email"
          type="email"
          name="email"
          className="Tinput"
          onChange={handleChange}
          required
        />

        <label htmlFor="coord-pwd">Mot de passe</label>
        <input
          id="coord-pwd"
          type="password"
          name="password"
          className="Tinput"
          onChange={handleChange}
          required
        />

        <button type="submit" className="Lbtn" disabled={loading}>
          {loading ? "Connexion..." : "Se connecter"}
        </button>

        {message && <p style={{ marginTop: "10px" }}>{message}</p>}

        {/* ← 3. Remplacer <a href="/"> par un bouton */}
        <p className="PSup">
          <button type="button" onClick={goToLogin} className="ToggBtn">
            Espace étudiant
          </button>
        </p>

      </form>
    </div>
  );
}