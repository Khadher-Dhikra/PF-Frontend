import { useState } from "react";  // ← useEffect non utilisé, retiré
import PropositionsList from "./PropositionsList";
import RoleManager from "./RoleManager";

export default function CoordDashboard({ goToLogin }) {  // ← 1. Ajouter goToLogin
  const [activeTab, setActiveTab] = useState("propositions");
  const coordNom = localStorage.getItem("coord_nom") || "Coordonnateur";

  const handleLogout = () => {
    localStorage.removeItem("coord_token");
    localStorage.removeItem("coord_id");
    localStorage.removeItem("coord_nom");

    goToLogin();  // ← 2. Remplacer window.location.href par goToLogin()
  };

  return (
    <div style={{ padding: "2em", maxWidth: "1100px", margin: "0 auto" }}>

     {/* Header */}
<div style={{
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: "2em"
}}>
  <div>
    <h1 style={{ margin: 0 }}>Tableau de bord</h1>
    <p className="pd">Bienvenue, {coordNom}</p>
  </div>
  <button
    onClick={handleLogout}
    className="Lbtn"
    style={{ width: "auto", padding: "0.5em 1.5em", whiteSpace: "nowrap" }}
  >
    Se déconnecter
  </button>
</div>

{/* Tabs */}
<div style={{ display: "flex", gap: "1em", marginBottom: "2em" }}>
  <button
    onClick={() => setActiveTab("propositions")}
    className={activeTab === "propositions" ? "Lbtn" : "ToggBtn"}
    style={{ border: "1px solid indigo", padding: "0.5em 1.5em", borderRadius: "5px", whiteSpace: "nowrap" }}
  >
    Propositions
  </button>
  <button
    onClick={() => setActiveTab("roles")}
    className={activeTab === "roles" ? "Lbtn" : "ToggBtn"}
    style={{ border: "1px solid indigo", padding: "0.5em 1.5em", borderRadius: "5px", whiteSpace: "nowrap" }}
  >
    Gestion des rôles
  </button>
</div>

      {/* Content */}
      {activeTab === "propositions" && <PropositionsList />}
      {activeTab === "roles"        && <RoleManager />}

    </div>
  );
}