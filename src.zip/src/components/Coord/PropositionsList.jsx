import { useState, useEffect } from "react";

export default function PropositionsList() {
  const [propositions, setPropositions] = useState([]);
  const [loading, setLoading]           = useState(true);
  const [message, setMessage]           = useState("");

  const token = localStorage.getItem("coord_token");

  useEffect(() => {
    fetchPropositions();
  }, []);

  const fetchPropositions = async () => {
    try {
      const response = await fetch(
        "http://localhost:8000/api/get-propositions.php",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": token
          }
        }
      );

      const data = await response.json();

      if (data.status === "success") {
        setPropositions(data.propositions);
      } else {
        setMessage(data.message);
      }

    } catch (error) {
      setMessage("Server error");
      console.error(error);
    }

    setLoading(false);
  };

  if (loading) return <p>Chargement...</p>;

  return (
    <div>
      <h2>Toutes les propositions</h2>

      {message && <p style={{ color: "red" }}>{message}</p>}

      {propositions.length === 0 ? (
        <p className="pd">Aucune proposition pour le moment.</p>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "indigo", color: "white" }}>
              <th style={{ padding: "0.7em", textAlign: "left" }}>ID</th>
              <th style={{ padding: "0.7em", textAlign: "left" }}>Titre</th>
              <th style={{ padding: "0.7em", textAlign: "left" }}>Étudiant</th>
              <th style={{ padding: "0.7em", textAlign: "left" }}>Statut</th>
              <th style={{ padding: "0.7em", textAlign: "left" }}>Date</th>
            </tr>
          </thead>
          <tbody>
            {propositions.map((p, i) => (
              <tr
                key={p.id}
                style={{ background: i % 2 === 0 ? "#f9f9f9" : "white", borderBottom: "1px solid #eee" }}
              >
                <td style={{ padding: "0.7em" }}>{p.id}</td>
                <td style={{ padding: "0.7em" }}>{p.titre}</td>
                <td style={{ padding: "0.7em" }}>{p.username}</td>
                <td style={{ padding: "0.7em" }}>
                  <span style={{
                    background: p.statut === "accepté" ? "#d4edda" : p.statut === "refusé" ? "#f8d7da" : "#fff3cd",
                    color:      p.statut === "accepté" ? "#155724" : p.statut === "refusé" ? "#721c24" : "#856404",
                    padding: "0.2em 0.7em",
                    borderRadius: "12px",
                    fontSize: "0.85em"
                  }}>
                    {p.statut}
                  </span>
                </td>
                <td style={{ padding: "0.7em" }}>{p.created_at}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}