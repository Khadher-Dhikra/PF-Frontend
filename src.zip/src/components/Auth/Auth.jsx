import { useState } from 'react';
import Login          from './login';
import Register       from './register';
import ForgotPassword from './ForgotPassword';
import CoordLogin     from '../Coord/CoordLogin';
import CoordDashboard from '../Coord/CoordDashboard';
import DivImage       from '../UI/divimage';
import './Auth.css';

export default function Auth() {
  const [page, setPage]       = useState("login");
  const [animate, setAnimate] = useState("");

  const goToRegister = () => {
    setPage("register");
    setAnimate(prev => prev === "ann" ? "rann" : "ann");
  };

  const goToLogin = () => {
    setPage("login");
    setAnimate(prev => prev === "ann" ? "rann" : "ann");
  };

  const goToForgot     = () => setPage("forgot");
  const goToCoord      = () => setPage("coord-login");
  const goToDashboard  = () => setPage("coord-dashboard");

  // ── Espace coordonnateur (plein écran, sans DivImage) ──
  if (page === "coord-dashboard") {
    return <CoordDashboard goToLogin={goToLogin} />;
  }

  return (
    <>
      {page === "login"       && <Login       toggleForm={goToRegister} goToForgot={goToForgot} goToCoord={goToCoord} />}
      {page === "register"    && <Register    toggleForm={goToLogin} />}
      {page === "forgot"      && <ForgotPassword toggleForm={goToLogin} />}
      {page === "coord-login" && <CoordLogin  goToLogin={goToLogin} onSuccess={goToDashboard} />}
      <DivImage isLogin={page === "login"} animate={animate} />
    </>
  );
}